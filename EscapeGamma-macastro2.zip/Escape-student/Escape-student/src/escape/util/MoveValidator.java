package escape.util;

import escape.board.Board;
import escape.board.LocationType;
import escape.board.coordinate.Coordinate;
import escape.piece.EscapePiece;

import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.stream.Collectors;

public class MoveValidator {
    private EscapePiece pieceToMove;
    private Board board;
    private Coordinate to;
    private Coordinate from;

    /**
     * Constructor
     * @param pieceToMove piece being moved
     * @param board board on which piece is being moved
     * @param to coord where piece wants to go
     * @param from coord where piece came from
     */
    public MoveValidator(EscapePiece pieceToMove, Board board, Coordinate to, Coordinate from) {
        this.pieceToMove = pieceToMove;
        this.board = board;
        this.to = to;
        this.from = from;
    }

    /**
     * Validates the given move
     * @return true if valid, false if invalid
     */
    public boolean validate(){
        if(!passesUniversalRules()){
            return false;
        }
        List<Coordinate> path = pathFind();
        if(path == null){
            return false;
        }else{
            if(path.size()-1 > pieceToMove.getTravelDistance()){
                return false;
            }
//            if(board.getLocation(path.get(0)) == LocationType.EXIT){
//
//            }
        }
        return true;

    }

    /**
     * Checks if the movement passes rules that apply to piece
     * @return false if no, true if yes
     */
    public boolean passesUniversalRules(){
        if(board.getLocation(to) == LocationType.BLOCK){
            return false;
        }

        if(board.getPieceAt(from) == null){
            return false;
        }

        if(board.getPieceAt(to) != null && board.getPieceAt(to).getPlayer() == board.getPieceAt(from).getPlayer()){
            return false;
        }

        return true;
    }

    /**
     * Breadth first search implementation
     * @return the path taken
     */
    private List<Coordinate> pathFind(){

        HashMap<Coordinate,Coordinate> parents = new HashMap<>();
        Queue<Coordinate> queue = new ConcurrentLinkedQueue<>();
        HashSet<Coordinate> discovered = new HashSet<>();
        queue.add(from);
        discovered.add(from);

        while(!queue.isEmpty()){
            Coordinate currentCord = queue.poll();
            if(currentCord.equals(to)){
                return parseBFT(parents);
            }
            List<Coordinate> neighborList = filterNeighbors(currentCord.getNeighbors(), currentCord,parents);
            for(Coordinate neighbor : neighborList){
                if(!discovered.contains(neighbor)){
                    discovered.add(neighbor);
                    parents.put(neighbor,currentCord);
                    queue.add(neighbor);
                }
            }
        }
        return null;

    }


    /**
     * Parses breadth first tree to figure out shortest path from destination to source
     * @param map breadth first tree
     * @return
     */
    private List<Coordinate> parseBFT(Map<Coordinate,Coordinate> map){
        Coordinate parseCoord = to;

        LinkedList<Coordinate> path = new LinkedList<>();
        path.add(parseCoord);

        while(parseCoord != from){
            parseCoord = map.get(parseCoord);
            path.add(parseCoord);
        }
        System.out.println(path);
        return path;
    }

    /**
     * Filters out neighbors based on movement patterns and attributes
     * @param neighbors A list of neighbors of source
     * @param source the source coordinate
     * @param map a map of the paths so far
     * @return
     */
    private List<Coordinate> filterNeighbors(List<Coordinate> neighbors, Coordinate source, Map<Coordinate,Coordinate> map){

        switch(pieceToMove.getMovementPattern()){
            case ORTHOGONAL:
                neighbors = neighbors.stream().filter(c->{
                    if((source.getX() == c.getX()+1 || source.getX() == c.getX()-1) && source.getY() == c.getY()){
                        return true;
                    }

                    if((source.getY() == c.getY()+1 || source.getY() == c.getY()-1) && source.getX() == c.getX()){
                        return true;
                    }
                    return false;

                }).collect(Collectors.toList());
                break;
            case LINEAR:
                neighbors = neighbors.stream().filter(c->{
                    Coordinate previous = map.get(source);
                    //Coordinate previous = map.get(c);
                    if(previous == null){
                        return true;
                    }

                    if(shoelaceFormula(previous,source,c) == 0){
                        return true;
                    }else{
                        return false;
                    }

                }).collect(Collectors.toList());
                break;
            case OMNI:
                break;
            case DIAGONAL:
                neighbors = neighbors.stream().filter(c->{
                    if((source.getX() == c.getX()+1 || source.getX() == c.getX()-1) && source.getY() == c.getY()){
                        return false;
                    }

                    if((source.getY() == c.getY()+1 || source.getY() == c.getY()-1) && source.getX() == c.getX()){
                        return false;
                    }
                    return true;

                }).collect(Collectors.toList());
                break;

        }
        if(pieceToMove.isCanJump()){
            neighbors = neighbors.stream().filter(c-> filterJump(source,c)).collect(Collectors.toList());
        }else{
            neighbors = neighbors.stream().filter(c->{
               if(board.getPieceAt(c) != null){
                   if(pieceToMove.isCanFly()){
                       return true;
                   }
                   return false;
               }else{
                   return true;
               }
            }).collect(Collectors.toList());
        }

        List<Coordinate> reducedNeighbors = neighbors.stream()
                .filter(this::filterOutOfBounds)
                .filter(this::filterBlockLocations)
                .filter(this::filterOutOfAbsoluteRange)
                //.filter(this::filterJump)
                .collect(Collectors.toList());


        return reducedNeighbors;
    }


    /**
     * Filters out coordinates which are out of bounds
     * @param n coord
     * @return
     */
    private boolean filterOutOfBounds(Coordinate n){
        if(board.getMaxX() != -1 && board.getMaxY() != -1){ //Is Hex Board?
            if(n.getX() > board.getMaxX() || n.getX() < 1){
                return false;
            }
            if(n.getY() > board.getMaxY() || n.getY() < 1){
                return false;
            }
        }
        return true;
    }

    /**
     * Filters out coordinates which are blocked
     * @param n coord
     * @return
     */
    private boolean filterBlockLocations(Coordinate n){
        if(board.getLocation(n) != null){
            if(board.getLocation(n) == LocationType.BLOCK && (!pieceToMove.isCanPassThroughBlocks() && !pieceToMove.isCanFly())){
                return false;
            }
        }
        return true;
    }


    /**
     * Filters out coordinates which are not jumpable
     * @param source the source coordinate making the jump
     * @param n the coordinate that has a piece on it
     * @return true if coordinate is jumpable
     */
    private boolean filterJump(Coordinate source, Coordinate n) {

        if (board.getPieceAt(n) != null) {
            for (Coordinate n2 : n.getNeighbors()) {
                if (board.getPieceAt(n2) == null && board.getLocation(n2) != LocationType.BLOCK) {
                    if (shoelaceFormula(source, n, n2) == 0) {
                        return true;
                    }
                }

            }
            return false;
        }
        return true;
    }

    /**
     * Filters coordinates that are outside of the distanceTo range
     * @param n coordniate
     * @return
     */
    private boolean filterOutOfAbsoluteRange(Coordinate n){
        if(from.distanceTo(n) > pieceToMove.getTravelDistance()){
            return false;
        }else{
            return true;
        }
    }


    /**
     * Calculates the area of a triangle with the 3 given coordinates
     * @param one
     * @param two
     * @param three
     * @return area
     */
    private int shoelaceFormula(Coordinate one, Coordinate two, Coordinate three){
        return (one.getX() * (two.getY()-three.getY()) +
                two.getX() * (three.getY()-one.getY()) +
                three.getX() * (one.getY()-two.getY()));
    }








}

package escape;

import escape.board.Board;
import escape.board.LocationType;
import escape.board.coordinate.Coordinate;
import escape.piece.EscapePiece;
import escape.util.MoveValidator;
import escape.util.PieceTypeInitializer;

public class EscapeGameManagerImplementation<C extends Coordinate> implements EscapeGameManager<C>{

    private Board<C> board;

    public EscapeGameManagerImplementation(Board<C> board) {
        this.board = board;

    }
    /**
     * Make the move in the current game.
     * @param from starting location
     * @param to ending location
     * @return true if the move was legal, false otherwise
     */
    @Override
    public boolean move(Coordinate from, Coordinate to) {
        MoveValidator moveValidator = new MoveValidator(getPieceAt(from),board,to,from);
        if(moveValidator.validate()){

            board.putPieceAt(getPieceAt(from), (C) to);
            board.removePiece(from);
            if(board.getLocation((C) to) == LocationType.EXIT){
                board.removePiece(to);
            }


            return true;
        }else{
            return false;
        }
    }

    /**
     * Return the piece located at the specified coordinate. If executing
     * this method in the game instance causes an exception, then this method
     * returns null and sets the status message appropriately.
     * @param coordinate the location to probe
     * @return the piece at the specified location or null if there is none
     */
    @Override
    public EscapePiece getPieceAt(Coordinate coordinate) {

        return board.getPieceAt((C) coordinate);
    }

    /**
     * Returns a coordinate of the appropriate type. If the coordinate cannot be
     * created, then null is returned and the status message is set appropriately.
     * @param x the x component
     * @param y the y component
     * @return the coordinate or null if the coordinate cannot be
     */
    @Override
    public C makeCoordinate(int x, int y) {
        return board.createCoord(x,y);
    }

}

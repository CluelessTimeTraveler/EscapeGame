/*******************************************************************************
 * This files was developed for CS4233: Object-Oriented Analysis & Design.
 * The course was taken at Worcester Polytechnic Institute.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Copyright ©2020 Gary F. Pollice
 *******************************************************************************/

package escape.piece;

import java.util.Objects;

/**
 * This is a class for Pieces.
 * 
 * You may change this class except for the signature of the static factory 
 * method makePiece() and the getter methods for the name and player.
 * 
 * @version Mar 28, 2020
 */
public class EscapePiece
{
    private final PieceName name;
    private final Player player;

    private MovementPatternID movementPattern;
    private int valueOfPiece;

	public MovementPatternID getMovementPattern() {
		return movementPattern;
	}

	public void setMovementPattern(MovementPatternID movementPattern) {
		this.movementPattern = movementPattern;
	}

	public int getValueOfPiece() {
		return valueOfPiece;
	}

	public void setValueOfPiece(int valueOfPiece) {
		this.valueOfPiece = valueOfPiece;
	}

	public int getTravelDistance() {
		return travelDistance;
	}

	public void setTravelDistance(int travelDistance) {
		this.travelDistance = travelDistance;
	}

	public boolean isCanJump() {
		return canJump;
	}

	public void setCanJump(boolean canJump) {
		this.canJump = canJump;
	}

	public boolean isCanPassThroughBlocks() {
		return canPassThroughBlocks;
	}

	public void setCanPassThroughBlocks(boolean canPassThroughBlocks) {
		this.canPassThroughBlocks = canPassThroughBlocks;
	}

	public boolean isCanFly() {
		return canFly;
	}

	public void setCanFly(boolean canFly) {
		this.canFly = canFly;
	}

	private int travelDistance;
    private boolean canJump = false;
    private boolean canPassThroughBlocks = false;
    private boolean canFly = false;

    
    /**
     * Constructor that takes the player and piece name.
     * @param player
     * @param name
     */
    public EscapePiece(Player player, PieceName name) 
    {
    	this.player = player;
    	this.name = name;
    }


	
	/**
	 * Static factory method. This creates and returns the specified
	 * Escape piece for the current game version.
	 * 
	 * DO NOT CHANGE THE SIGNATURE.
	 * @param player the player the piece belongs to
	 * @param name the piee name
	 * @return the piece
	 */
	public static EscapePiece makePiece(Player player, PieceName name)
	{
		return new EscapePiece(player, name);
	}

	/**
	 * @return the name
	 */
	public PieceName getName()
	{
		return name;
	}
	
	/**
	 * @return the player
	 */
	public Player getPlayer()
	{
		return player;
	}


	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		EscapePiece that = (EscapePiece) o;
		return name == that.name &&
				player == that.player;
	}

	@Override
	public int hashCode() {
		return Objects.hash(name, player);
	}
}

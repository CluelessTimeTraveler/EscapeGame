package escape.board.coordinate;

import java.util.ArrayList;
import java.util.Objects;

public class OrthoSquareCoordinate implements Coordinate {


    private final int x;
    private final int y;

    private OrthoSquareCoordinate(int x, int y)
    {
        this.x = x;
        this.y = y;
    }

    public static OrthoSquareCoordinate makeCoordinate(int x, int y){
        return new OrthoSquareCoordinate(x,y);
    }

    @Override
    public int getX() {
        return x;
    }

    @Override
    public int getY() {
        return y;
    }
    /*
     * @see escape.board.coordinate.Coordinate#distanceTo(escape.board.coordinate.Coordinate)
     */
    @Override
    public int distanceTo(Coordinate c) {
        return Math.abs(c.getX()-x) + Math.abs(c.getY()-y);
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(x, y);
    }

    /*
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof OrthoSquareCoordinate)) {
            return false;
        }
        OrthoSquareCoordinate other = (OrthoSquareCoordinate) obj;
        return x == other.x && y == other.y;
    }

    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }

    @Override
    public ArrayList<Coordinate> getNeighbors() {
        ArrayList<Coordinate> neighborList = new ArrayList<>();

        neighborList.add(makeCoordinate(this.x+1,this.y));
        neighborList.add(makeCoordinate(this.x-1,this.y));
        neighborList.add(makeCoordinate(this.x,this.y-1));
        neighborList.add(makeCoordinate(this.x,this.y+1));

        return neighborList;
    }

}

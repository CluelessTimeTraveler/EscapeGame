package escape.board.coordinate;

import escape.piece.MovementPatternID;

import java.util.ArrayList;

public interface XYCoordinate {
    int getX();
    int getY();
    ArrayList<Coordinate> getNeighbors();
}

package escape.board.coordinate;

import java.util.ArrayList;
import java.util.Objects;

public class HexCoordinate implements Coordinate{

    private final int x;
    private final int y;

    private HexCoordinate(int x, int y)
    {
        this.x = x;
        this.y = y;
    }

    public static HexCoordinate makeCoordinate(int x, int y){
        return new HexCoordinate(x,y);
    }

    /*
     * @see escape.board.coordinate.Coordinate#distanceTo(escape.board.coordinate.Coordinate)
     */
    @Override
    public int distanceTo(Coordinate c) {
        //return Math.max((Math.abs(c.getX()-c.getY())*-1) - (Math.abs(x-y)*-1),Math.max(Math.abs(c.getX()-x),Math.abs(c.getY()-y)));

        //return Math.abs(c.getX()-x) + Math.abs(c.getY()-y);

        if(x==c.getX() && y==c.getY()){
            return 0;
        }

        if(((x^y) < 0) && ((c.getX()^c.getY()) < 0)){
            return Math.max((Math.abs(c.getX()-x)*-1) - (Math.abs(c.getY()-y)*-1),Math.max(Math.abs(c.getX()-x),Math.abs(c.getY()-y)));

        }else{
            //return Math.max(Math.abs(c.getX()) + Math.abs(x) + Math.abs(c.getY()) + Math.abs(y),0);
            return Math.abs(c.getX()-x) + Math.abs(c.getY()-y);
        }


       //return Math.max((Math.abs(c.getX()-x)*-1) - (Math.abs(c.getY()-y)*-1),Math.max(Math.abs(c.getX()-x),Math.abs(c.getY()-y)));

        //return Math.max(Math.abs(c.getX()-x) + Math.abs(c.getY()-y),Math.abs(c.getX()-x),Math.abs(c.getY()-y));
    }

    @Override
    public int getX() {
        return x;
    }

    @Override
    public int getY() {
        return y;
    }

    /*
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode()
    {
        return Objects.hash(x, y);
    }

    /*
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof HexCoordinate)) {
            return false;
        }
        HexCoordinate other = (HexCoordinate) obj;
        return x == other.x && y == other.y;
    }

    /*
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        return "(" + x + ", " + y + ")";
    }

    @Override
    public ArrayList<Coordinate> getNeighbors() {

        ArrayList<Coordinate> neighborList = new ArrayList<>();

        neighborList.add(makeCoordinate(this.x+1,this.y));
        neighborList.add(makeCoordinate(this.x-1,this.y));
        neighborList.add(makeCoordinate(this.x,this.y-1));
        neighborList.add(makeCoordinate(this.x,this.y+1));
        neighborList.add(makeCoordinate(this.x+1,this.y-1));
        neighborList.add(makeCoordinate(this.x-1,this.y+1));

        return neighborList;
    }

}

package escape.board;

import escape.board.coordinate.CoordinateID;

/**
 * Functional Interface for a BoardFactoryMethod
 */
@FunctionalInterface
public interface BoardFactoryMethod {
    /**
     * Creates a board with given coordinates
     * @param x coord
     * @param y coord
     * @return board of appropriate type
     */
    Board factoryCreate(int x, int y);
}

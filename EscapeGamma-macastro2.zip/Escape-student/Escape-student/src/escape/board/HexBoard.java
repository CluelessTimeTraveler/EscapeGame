package escape.board;

import escape.board.coordinate.Coordinate;
import escape.board.coordinate.HexCoordinate;
import escape.board.coordinate.OrthoSquareCoordinate;
import escape.board.coordinate.SquareCoordinate;
import escape.exception.EscapeException;
import escape.piece.EscapePiece;

import java.util.HashMap;
import java.util.Map;

public class HexBoard implements Board<HexCoordinate>{

    Map<HexCoordinate, LocationType> squares;
    Map<HexCoordinate, EscapePiece> pieces;

    private final int xMax, yMax;
    public HexBoard(int xMax, int yMax)
    {
        this.xMax = xMax;
        this.yMax = yMax;
        pieces = new HashMap<HexCoordinate, EscapePiece>();
        squares = new HashMap<HexCoordinate, LocationType>();
    }


    @Override
    public EscapePiece getPieceAt(HexCoordinate coord) {
        return pieces.get(coord);
    }

    @Override
    public void putPieceAt(EscapePiece p, HexCoordinate coord) {
        if(squares.get(coord) == LocationType.CLEAR || squares.get(coord) == null){
            pieces.put(coord,p);
        }else{
            if(squares.get(coord) != LocationType.EXIT){
                throw new EscapeException("Unable to put piece, space is blocked");
            }
        }
    }
    public void setLocationType(HexCoordinate c, LocationType lt)
    {
        squares.put(c, lt);
    }

    @Override
    public HexCoordinate createCoord(int x, int y) {
        return HexCoordinate.makeCoordinate(x,y);
    }

    @Override
    public LocationType getLocation(HexCoordinate c) {
        return squares.get(c);
    }

    @Override
    public int getMaxY() {
        return -1; //Hex boards are infinite
    }

    @Override
    public int getMaxX() {
        return -1; //Hex boards are infinite
    }

    @Override
    public void removePiece(Coordinate c) {
        pieces.remove(c);
    }
}

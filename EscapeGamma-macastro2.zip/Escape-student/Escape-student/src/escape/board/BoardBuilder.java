/*******************************************************************************
 * This files was developed for CS4233: Object-Oriented Analysis & Design.
 * The course was taken at Worcester Polytechnic Institute.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-2.0/
 * 
 * Copyright ©2016-2020 Gary F. Pollice
 *******************************************************************************/
package escape.board;

import static escape.board.LocationType.CLEAR;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import javax.xml.bind.*;

import escape.board.coordinate.Coordinate;
import escape.board.coordinate.CoordinateID;
import escape.board.coordinate.SquareCoordinate;
import escape.piece.EscapePiece;
import escape.piece.PieceAttributeID;
import escape.util.*;

/**
 * A Builder class for creating Boards. It is only an example and builds
 * just Square boards. If you choose to use this
 * @version Apr 2, 2020
 */
public class BoardBuilder
{
	private BoardInitializer bi;
	private Map<CoordinateID,BoardFactoryMethod> factoryMap; //Map of BoardFactoryMethods
	private PieceTypeInitializer[] pti;



	/**
	 * The constructor for this takes a file name. It is either an absolute path
	 * or a path relative to the beginning of this project.
	 * @param fileName
	 * @throws Exception 
	 */
	public BoardBuilder(File fileName) throws Exception
	{
		JAXBContext contextObj = JAXBContext.newInstance(BoardInitializer.class);
        Unmarshaller mub = contextObj.createUnmarshaller();
        bi = (BoardInitializer)mub.unmarshal(new FileReader(fileName));
        factoryMap = new HashMap<>();
        factoryMap.put(CoordinateID.SQUARE, this::createSquareBoard);
		factoryMap.put(CoordinateID.HEX, this::createHexBoard);
		factoryMap.put(CoordinateID.ORTHOSQUARE, this::createOrthoSquareBoard);
	}

	public BoardBuilder(BoardInitializer bi, PieceTypeInitializer[] pti){
		factoryMap = new HashMap<>();
		factoryMap.put(CoordinateID.SQUARE, this::createSquareBoard);
		factoryMap.put(CoordinateID.HEX, this::createHexBoard);
		factoryMap.put(CoordinateID.ORTHOSQUARE, this::createOrthoSquareBoard);
		this.bi = bi;
		this.pti = pti;
	}
	
	public Board makeBoard()
	{
		// Change next when we have Hex boards too.
        //Board board = new SquareBoard(bi.getxMax(), bi.getyMax());
        Board board = factoryMap.get(bi.getCoordinateId()).factoryCreate(bi.getxMax(),bi.getyMax());
        initializeBoard(board, bi.getLocationInitializers());
        return board;
	}
	
	private void initializeBoard(Board b, LocationInitializer... initializers)
	{
		if(initializers == null){
			return;
		}
		for (LocationInitializer li : initializers) {
			Coordinate c = b.createCoord(li.x,li.y);
			if (li.pieceName != null) {
				EscapePiece newPiece = new EscapePiece(li.player, li.pieceName);
				if(pti != null){
					for(PieceTypeInitializer p : pti){
						if(p.getPieceName() == li.pieceName){
							newPiece.setMovementPattern(p.getMovementPattern());
							for(PieceTypeInitializer.PieceAttribute pa : p.getAttributes()){
								switch(pa.getId()){
									case VALUE:
										newPiece.setValueOfPiece(pa.getIntValue());
										break;
									case DISTANCE:
										newPiece.setTravelDistance(pa.getIntValue());
										break;
									case JUMP:
										newPiece.setCanJump(pa.isBooleanValue());
										break;
									case UNBLOCK:
										newPiece.setCanPassThroughBlocks(pa.isBooleanValue());
										break;
									case FLY:
										newPiece.setCanFly(true);
										newPiece.setTravelDistance(pa.getIntValue());
										break;
								}
							}
							break;
						}
					}
				}
				b.putPieceAt(newPiece, c);
			}
			if (li.locationType != null && li.locationType != CLEAR) {
				b.setLocationType(c, li.locationType);
			}
		}
	}

	/**
	 * Creates a hex board
	 * @param x
	 * @param y
	 * @return
	 */
	private Board createHexBoard(int x, int y){
		return new HexBoard(x,y);
	}

	/**
	 * Creates a hex board
	 * @param x max
	 * @param y max
	 * @return
	 */
	private Board createSquareBoard(int x, int y){
		return new SquareBoard(x,y);
	}

	/**
	 * Creates a hex board
	 * @param x max
	 * @param y max
	 * @return
	 */
	private Board createOrthoSquareBoard(int x, int y){
		return new OrthoBoard(x,y);
	}

}

package escape.board;

import escape.board.coordinate.Coordinate;
import escape.board.coordinate.OrthoSquareCoordinate;

/**
 * Interface to add methods to Board interface without modifying existing interface
 * @param <CoordSystem>
 */
public interface BuildableBoard<CoordSystem extends Coordinate> {
    /**
     * Sets location type of a given coordinate
     * @param c coord
     * @param lt LocationType
     */
    void setLocationType(CoordSystem c, LocationType lt);

    /**
     * Creates a coord of the given coord system
     * @param x coord
     * @param y coord
     * @return Coordinate object
     */
    CoordSystem createCoord(int x, int y);

    /**
     * Gets the location type of a given coordinate
     * @param c coord
     * @return LocationType
     */
    LocationType getLocation(CoordSystem c);

    int getMaxY();
    int getMaxX();

    void removePiece(Coordinate c );

}

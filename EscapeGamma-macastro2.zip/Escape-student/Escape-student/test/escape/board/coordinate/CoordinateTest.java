/*******************************************************************************
 * This files was developed for CS4233: Object-Oriented Analysis & Design.
 * The course was taken at Worcester Polytechnic Institute.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Copyright ©2020 Gary F. Pollice
 *******************************************************************************/

package escape.board.coordinate;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.Objects;

/**
 * Tests for various coordinates
 * @version Mar 28, 2020
 */
class CoordinateTest
{
    
   @Test
    void testDistanceToSquareCoord(){
       SquareCoordinate squareCoord1 = SquareCoordinate.makeCoordinate(0,0);
       SquareCoordinate squareCoord2 = SquareCoordinate.makeCoordinate(4,5);
       assertEquals(5,squareCoord1.distanceTo(squareCoord2));
   }

    @Test
    void testDistanceToSquareCoord2(){
        SquareCoordinate squareCoord1 = SquareCoordinate.makeCoordinate(4,5);
        SquareCoordinate squareCoord2 = SquareCoordinate.makeCoordinate(4,5);
        assertEquals(0,squareCoord1.distanceTo(squareCoord2));
    }

    @Test
    void testDistanceToSquareCoord3(){
        SquareCoordinate squareCoord1 = SquareCoordinate.makeCoordinate(5,5);
        SquareCoordinate squareCoord2 = SquareCoordinate.makeCoordinate(1,2);
        assertEquals(4,squareCoord1.distanceTo(squareCoord2));
    }

    @Test
    void testDistanceToOrthoCoord4(){
        OrthoSquareCoordinate Coord1 = OrthoSquareCoordinate.makeCoordinate(1,2);
        OrthoSquareCoordinate Coord2 = OrthoSquareCoordinate.makeCoordinate(3,5);
        assertEquals(5,Coord1.distanceTo(Coord2));
    }

    @Test
    void testDistanceToOrthoCoord5(){
        OrthoSquareCoordinate Coord1 = OrthoSquareCoordinate.makeCoordinate(1,1);
        OrthoSquareCoordinate Coord2 = OrthoSquareCoordinate.makeCoordinate(2,2);
        assertEquals(2,Coord1.distanceTo(Coord2));
    }

    @Test
    void testDistanceToHexCoord5(){
        HexCoordinate Coord1 = HexCoordinate.makeCoordinate(2,0);
        HexCoordinate Coord2 = HexCoordinate.makeCoordinate(-1,1);
        assertEquals(4,Coord1.distanceTo(Coord2));
    }

    @Test
    void testDistanceToHexCoord6(){
        HexCoordinate Coord1 = HexCoordinate.makeCoordinate(0,2);
        HexCoordinate Coord2 = HexCoordinate.makeCoordinate(-1,0);
        assertEquals(3,Coord1.distanceTo(Coord2));
    }

    @Test
    void testDistanceToHexCoord7(){
        HexCoordinate Coord1 = HexCoordinate.makeCoordinate(2,2);
        HexCoordinate Coord2 = HexCoordinate.makeCoordinate(2,2);
        assertEquals(0,Coord1.distanceTo(Coord2));
    }

    @Test
    void testDistanceToHexCoord8(){
        HexCoordinate Coord1 = HexCoordinate.makeCoordinate(-4,5);
        HexCoordinate Coord2 = HexCoordinate.makeCoordinate(4,-3);
        assertEquals(8,Coord1.distanceTo(Coord2));
    }

}

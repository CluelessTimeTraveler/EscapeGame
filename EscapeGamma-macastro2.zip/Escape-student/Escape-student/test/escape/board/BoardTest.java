/*******************************************************************************
 * This files was developed for CS4233: Object-Oriented Analysis & Design.
 * The course was taken at Worcester Polytechnic Institute.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-2.0/
 * 
 * Copyright ©2016-2020 Gary F. Pollice
 *******************************************************************************/
package escape.board;

import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.File;

import escape.board.coordinate.HexCoordinate;
import escape.board.coordinate.OrthoSquareCoordinate;
import escape.board.coordinate.SquareCoordinate;
import escape.exception.EscapeException;
import escape.piece.EscapePiece;
import escape.piece.PieceName;
import escape.piece.Player;
import org.junit.jupiter.api.Test;

/**
 * Description
 * @version Apr 2, 2020
 */
class BoardTest
{
	@Test
	void buildBoard1() throws Exception
	{
		BoardBuilder bb = new BoardBuilder(new File("config/board/BoardConfig1.xml"));
		assertNotNull(bb.makeBoard());
		// Now I will do some tests on this board and its contents.

	}

	@Test
	void SquareBoardFromXMLGetPiece() throws Exception
	{
		BoardBuilder bb = new BoardBuilder(new File("config/board/BoardConfig1.xml"));
		Board Square = bb.makeBoard();
		EscapePiece piece = Square.getPieceAt(SquareCoordinate.makeCoordinate(2,2));
		assertEquals(PieceName.HORSE, piece.getName());
		// Now I will do some tests on this board and its contents.

	}

	@Test
	void SquareBoardFromXMLPutPiece() throws Exception
	{
		BoardBuilder bb = new BoardBuilder(new File("config/board/BoardConfig1.xml"));
		Board Square = bb.makeBoard();
		// piece = Square.getPieceAt(SquareCoordinate.makeCoordinate(2,2));
		assertThrows(EscapeException.class, ()->Square.putPieceAt((new EscapePiece(Player.PLAYER1, PieceName.HORSE)), SquareCoordinate.makeCoordinate(3,5)));


	}

	@Test
	void SquareBoardFromXMLGetPieceWithEmptySpot() throws Exception
	{
		BoardBuilder bb = new BoardBuilder(new File("config/board/BoardConfig1.xml"));
		Board Square = bb.makeBoard();
		EscapePiece piece = Square.getPieceAt(SquareCoordinate.makeCoordinate(3,3));
		assertNull(piece);


	}

	@Test
	void buildBoardHex() throws Exception
	{
		BoardBuilder bb = new BoardBuilder(new File("config/board/BoardConfig2Hex.xml"));
		assertNotNull(bb.makeBoard());

	}

	@Test
	void HexBoardFromXMLGetPiece() throws Exception
	{
		BoardBuilder bb = new BoardBuilder(new File("config/board/BoardConfig2Hex.xml"));
		Board Hex = bb.makeBoard();
		EscapePiece piece = Hex.getPieceAt(HexCoordinate.makeCoordinate(2,2));
		assertEquals(PieceName.HORSE, piece.getName());

	}

	@Test
	void HexBoardFromXMLPutPiece() throws Exception
	{
		BoardBuilder bb = new BoardBuilder(new File("config/board/BoardConfig2Hex.xml"));
		Board Hex = bb.makeBoard();
		assertThrows(EscapeException.class, ()->Hex.putPieceAt((new EscapePiece(Player.PLAYER1, PieceName.HORSE)), HexCoordinate.makeCoordinate(3,5)));

	}

	@Test
	void HexBoardFromXMLGetPieceWithEmptySpot() throws Exception
	{
		BoardBuilder bb = new BoardBuilder(new File("config/board/BoardConfig2Hex.xml"));
		Board Hex = bb.makeBoard();
		EscapePiece piece = Hex.getPieceAt(HexCoordinate.makeCoordinate(3,3));
		assertNull(piece);

	}

	@Test
	void buildBoardOrtho() throws Exception
	{
		BoardBuilder bb = new BoardBuilder(new File("config/board/BoardConfig3Ortho.xml"));
		assertNotNull(bb.makeBoard());
	}

	@Test
	void OrthoBoardFromXMLGetPiece() throws Exception
	{
		BoardBuilder bb = new BoardBuilder(new File("config/board/BoardConfig3Ortho.xml"));
		Board Ortho = bb.makeBoard();
		EscapePiece piece = Ortho.getPieceAt(OrthoSquareCoordinate.makeCoordinate(2,2));
		assertEquals(PieceName.HORSE, piece.getName());

	}

	@Test
	void OrthoBoardFromXMLPutPiece() throws Exception
	{
		BoardBuilder bb = new BoardBuilder(new File("config/board/BoardConfig3Ortho.xml"));
		Board Ortho = bb.makeBoard();
		assertThrows(EscapeException.class, ()->Ortho.putPieceAt((new EscapePiece(Player.PLAYER1, PieceName.HORSE)), OrthoSquareCoordinate.makeCoordinate(3,5)));

	}

	@Test
	void OrthoBoardFromXMLGetPieceWithEmptySpot() throws Exception
	{
		BoardBuilder bb = new BoardBuilder(new File("config/board/BoardConfig3Ortho.xml"));
		Board Ortho = bb.makeBoard();
		EscapePiece piece = Ortho.getPieceAt(OrthoSquareCoordinate.makeCoordinate(3,3));
		assertNull(piece);

	}

	//--------------------------------------------------SQUARE---------------------------------------------------------------------
	@Test
	void putOnSquareBoard1(){
		SquareBoard sb = new SquareBoard(10,10);
		assertThrows(EscapeException.class,()->sb.putPieceAt(new EscapePiece(Player.PLAYER1, PieceName.HORSE), SquareCoordinate.makeCoordinate(11,10)));

	}

	@Test
	void putOnSquareBoard2(){
		SquareBoard sb = new SquareBoard(10,10);
		sb.setLocationType(SquareCoordinate.makeCoordinate(10,10), LocationType.CLEAR);
		assertThrows(EscapeException.class,()->sb.putPieceAt(new EscapePiece(Player.PLAYER1, PieceName.HORSE), SquareCoordinate.makeCoordinate(10,11)));

	}

	@Test
	void putOnSquareBoard3(){
		SquareBoard sb = new SquareBoard(10,10);
		sb.setLocationType(SquareCoordinate.makeCoordinate(9,9), LocationType.BLOCK);
		assertThrows(EscapeException.class,()->sb.putPieceAt(new EscapePiece(Player.PLAYER1, PieceName.HORSE), SquareCoordinate.makeCoordinate(9,9)));

	}

	@Test
	void putOnSquareBoard4(){
		SquareBoard sb = new SquareBoard(10,10);
		sb.setLocationType(SquareCoordinate.makeCoordinate(9,9), LocationType.CLEAR);
		assertDoesNotThrow(()->sb.putPieceAt(new EscapePiece(Player.PLAYER1, PieceName.HORSE), SquareCoordinate.makeCoordinate(9,9)));
	}

	@Test
	void putOnSquareBoard5(){
		SquareBoard sb = new SquareBoard(10,10);
		sb.setLocationType(SquareCoordinate.makeCoordinate(9,9), LocationType.EXIT);
		assertDoesNotThrow(()->sb.putPieceAt(new EscapePiece(Player.PLAYER1, PieceName.HORSE), SquareCoordinate.makeCoordinate(9,9)));
	}

//--------------------------------------------------ORTHOSQUARE---------------------------------------------------------------------
	@Test
	void putOnOrthoSquareBoard1(){
		OrthoBoard sb = new OrthoBoard(10,10);
		assertThrows(EscapeException.class,()->sb.putPieceAt(new EscapePiece(Player.PLAYER1, PieceName.HORSE), OrthoSquareCoordinate.makeCoordinate(11,10)));
	}

	@Test
	void putOnOrthoSquareBoard2(){
		OrthoBoard sb = new OrthoBoard(10,10);
		assertThrows(EscapeException.class,()->sb.putPieceAt(new EscapePiece(Player.PLAYER1, PieceName.HORSE), OrthoSquareCoordinate.makeCoordinate(10,11)));
	}

	@Test
	void putOnOrthoSquareBoard3(){
		OrthoBoard sb = new OrthoBoard(10,10);
		sb.setLocationType(OrthoSquareCoordinate.makeCoordinate(9,9), LocationType.BLOCK);
		assertThrows(EscapeException.class,()->sb.putPieceAt(new EscapePiece(Player.PLAYER1, PieceName.HORSE), OrthoSquareCoordinate.makeCoordinate(9,9)));
	}

	@Test
	void putOnOrthoSquareBoard4(){
		OrthoBoard sb = new OrthoBoard(10,10);
		sb.setLocationType(OrthoSquareCoordinate.makeCoordinate(9,9), LocationType.CLEAR);
		assertDoesNotThrow(()->sb.putPieceAt(new EscapePiece(Player.PLAYER1, PieceName.HORSE), OrthoSquareCoordinate.makeCoordinate(9,9)));
	}

	@Test
	void putOnOrthoSquareBoard5() {
		OrthoBoard sb = new OrthoBoard(10, 10);
		sb.setLocationType(OrthoSquareCoordinate.makeCoordinate(9, 9), LocationType.EXIT);
		assertDoesNotThrow(() -> sb.putPieceAt(new EscapePiece(Player.PLAYER1, PieceName.HORSE), OrthoSquareCoordinate.makeCoordinate(9, 9)));
	}

	//--------------------------------------------------HEX---------------------------------------------------------------------
	@Test
	void putOnHexBoard3(){
		HexBoard sb = new HexBoard(0,0);
		sb.setLocationType(HexCoordinate.makeCoordinate(9,9), LocationType.BLOCK);
		assertThrows(EscapeException.class,()->sb.putPieceAt(new EscapePiece(Player.PLAYER1, PieceName.HORSE), HexCoordinate.makeCoordinate(9,9)));
	}

	@Test
	void putOnHexBoard4(){
		HexBoard sb = new HexBoard(0,0);
		sb.setLocationType(HexCoordinate.makeCoordinate(9,9), LocationType.CLEAR);
		assertDoesNotThrow(()->sb.putPieceAt(new EscapePiece(Player.PLAYER1, PieceName.HORSE), HexCoordinate.makeCoordinate(9,9)));
	}

	@Test
	void putOnHexBoard5(){
		HexBoard sb = new HexBoard(0,0);
		sb.setLocationType(HexCoordinate.makeCoordinate(9,9), LocationType.EXIT);
		assertDoesNotThrow(()->sb.putPieceAt(new EscapePiece(Player.PLAYER1, PieceName.HORSE), HexCoordinate.makeCoordinate(9,9)));
	}
	
}

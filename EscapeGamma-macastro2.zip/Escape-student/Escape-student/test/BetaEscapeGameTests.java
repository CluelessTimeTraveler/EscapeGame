/*******************************************************************************
 * This files was developed for CS4233: Object-Oriented Analysis & Design.
 * The course was taken at Worcester Polytechnic Institute.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Copyright ©2020 Gary F. Pollice
 *******************************************************************************/



import static org.junit.jupiter.api.Assertions.*;
import java.io.File;

import escape.EscapeGameBuilder;
import escape.EscapeGameManager;
import escape.EscapeGameManagerImplementation;
import escape.piece.EscapePiece;
import escape.piece.MovementPatternID;
import escape.piece.PieceName;
import escape.piece.Player;
import org.junit.jupiter.api.Test;

/**
 * Description
 * @version Apr 24, 2020
 */
class BetaEscapeGameTests
{
    
    /**
     * Example of how the game manager tests will be structured.
     * @throws Exception
     */
    @Test
    void creationTest() throws Exception
    {
        EscapeGameBuilder egb
            = new EscapeGameBuilder(new File("config/SampleEscapeGame.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        assertNotNull(emg);
        // Exercise the game now: make moves, check the board, etc.
    }

    @Test
    void piecesOnBoard() throws Exception
    {
        EscapeGameBuilder egb
                = new EscapeGameBuilder(new File("config/EscapeGameOnePiece.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapePiece ep = emg.getPieceAt(emg.makeCoordinate(2,2));
        EscapePiece tp = EscapePiece.makePiece(Player.PLAYER1, PieceName.HORSE);
        assertEquals(ep, tp);

    }

    @Test
    void testGameFoxAttributes() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestGameWithPiece.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        EscapePiece ep = egmi.getPieceAt(egmi.makeCoordinate(1,3));
        assertTrue(ep.isCanJump());
        assertFalse(ep.isCanFly());
        assertEquals(4,ep.getTravelDistance());
        assertEquals(MovementPatternID.ORTHOGONAL, ep.getMovementPattern());

    }

        @Test
    void testGameFoxMoveOntoBlock() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestGame.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(1,3),egmi.makeCoordinate(2,2)));

    }

    @Test
    void testGameFoxMoveOntoFriendly() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestGameWithPiece.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(1,3),egmi.makeCoordinate(3,3)));

    }

    @Test
    void testGameMoveNoPiece() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestGame.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(1,1),egmi.makeCoordinate(2,1)));

    }

    @Test
    void testGameMovePathFind() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestFoxNoJump.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertTrue(egmi.move(egmi.makeCoordinate(1,3),egmi.makeCoordinate(3,1)));

    }

    @Test
    void testGameMovePathFindDistanceLimited() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestGameWithPiece.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(1,3),egmi.makeCoordinate(5,1)));

    }

    @Test
    void testGameMoveDiagonalFlyPathFind() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestGameWithPiece.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertTrue(egmi.move(egmi.makeCoordinate(3,5),egmi.makeCoordinate(3,1)));

    }


    @Test
    void testGameMoveDiagonalPathFind() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestGameDiagonalWithPiece.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertTrue(egmi.move(egmi.makeCoordinate(3,5),egmi.makeCoordinate(3,1)));

    }

    @Test
    void testGameMoveDiagonalPathFindUnable() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestGameDiagonalWithPiece.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(3,5),egmi.makeCoordinate(3,2)));

    }

    @Test
    void testGameMoveLinearFailure() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestGameDiagonalWithPiece.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(4,7),egmi.makeCoordinate(5,5)));

    }

    @Test
    void testGameMoveLinear() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestLinear.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertTrue(egmi.move(egmi.makeCoordinate(4,7),egmi.makeCoordinate(7,7)));

    }

    @Test
    void testGameMoveLinearFailure2() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestLinear.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(4,7),egmi.makeCoordinate(1,3)));

    }

    @Test
    void testGameMoveLinearFailure3() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestLinear.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(4,7),egmi.makeCoordinate(4,1)));

    }

    @Test
    void testGameMoveLinearFailure4() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestLinear.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(4,5),egmi.makeCoordinate(1,2)));

    }

    @Test
    void testGameMoveLinearFailure5() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestLinear.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(4,5),egmi.makeCoordinate(4,7)));

    }

    @Test
    void testGameMoveLinearFailure6() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestLinear.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(4,5),egmi.makeCoordinate(7,2)));

    }
////////////////////////////////////////////////////////////////Frog Jump Tests///////////////////////////////////////////////////////
    @Test
    void testGameMoveLinearJumpFrog() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestGameFrogJumpReal.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertTrue(egmi.move(egmi.makeCoordinate(5,1),egmi.makeCoordinate(5,4)));

    }

    @Test
    void testGameMoveJumpFailure8() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestGameFrogJumpReal.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(4,1),egmi.makeCoordinate(4,4)));

    }

    @Test
    void testGameMoveJump8() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestGameFrogJumpReal.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertTrue(egmi.move(egmi.makeCoordinate(4,1),egmi.makeCoordinate(2,1)));

    }

    @Test
    void testGameMoveJump9() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestGameFrogJumpReal.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(3,1),egmi.makeCoordinate(6,4)));

    }

    @Test
    void testGameMoveJump10() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestGameFrogJumpReal.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(4,2),egmi.makeCoordinate(6,1)));

    }

    @Test
    void testGameMoveJump11() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestGameFrogJumpReal.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertTrue(egmi.move(egmi.makeCoordinate(4,2),egmi.makeCoordinate(8,6)));

    }

    @Test
    void testGameMoveJump12() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/TestGameFrogJumpReal.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(5,1),egmi.makeCoordinate(8,4)));

    }

//////////////////////////////////////////////////////////////TestFrogWithoutJump////////////////////////////////////////////

    @Test
    void testGameFrogWithoutJumping() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/NoJumpingFrog.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(5,1),egmi.makeCoordinate(5,4)));

    }

    ////////////////////////////////////////////HEX BOARD/////////////////////////////////////////////////
    @Test
    void testGameFrogHexg() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/HexLinearFrog.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(-1,0),egmi.makeCoordinate(1,1)));

    }

    @Test
    void testGameFrogHex2() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/HexLinearFrog.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertTrue(egmi.move(egmi.makeCoordinate(-1,0),egmi.makeCoordinate(2,0)));

    }

    @Test
    void testGameFrogHex3() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/HexFrogJump.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertTrue(egmi.move(egmi.makeCoordinate(-1,0),egmi.makeCoordinate(1,-2)));

    }

    @Test
    void testGameFrogHex4() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/BlockedJumpHex.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertFalse(egmi.move(egmi.makeCoordinate(-1,0),egmi.makeCoordinate(2,-3)));

    }

    @Test
    void testGameHummingBirdFly() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/FlyHexBoardTest.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));

        assertTrue(egmi.move(egmi.makeCoordinate(-1,0),egmi.makeCoordinate(2,-3)));

    }

    @Test
    void testGameHummingBirdFlyPlaced() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/FlyHexBoardTest.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));
        EscapePiece pieceToMove = egmi.getPieceAt(egmi.makeCoordinate(-1,0));
        egmi.move(egmi.makeCoordinate(-1,0),egmi.makeCoordinate(2,-3));
        EscapePiece pieceAfterMove = egmi.getPieceAt(egmi.makeCoordinate(2,-3));
        assertEquals(pieceToMove, pieceAfterMove);
        assertTrue(egmi.getPieceAt(egmi.makeCoordinate(-1,0))==null);

    }

    @Test
    void testGameExitTest() throws Exception
    {
        EscapeGameBuilder egb = new EscapeGameBuilder(new File("config/ExitTest.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        //egmi.placePiece(EscapePiece.makePiece(Player.PLAYER1,PieceName.FOX), egmi.makeCoordinate(1,2));
        EscapePiece pieceToMove = egmi.getPieceAt(egmi.makeCoordinate(-1,0));
        egmi.move(egmi.makeCoordinate(-1,0),egmi.makeCoordinate(2,0));
        EscapePiece pieceAfterMove = egmi.getPieceAt(egmi.makeCoordinate(2,0));
        //assertEquals(pieceToMove, pieceAfterMove);
        assertTrue(egmi.getPieceAt(egmi.makeCoordinate(-1,0))==null);
        assertTrue(egmi.getPieceAt(egmi.makeCoordinate(2,0))==null);
    }





}

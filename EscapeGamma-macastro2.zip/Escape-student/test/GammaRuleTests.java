/*******************************************************************************
 * This files was developed for CS4233: Object-Oriented Analysis & Design.
 * The course was taken at Worcester Polytechnic Institute.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *
 * Copyright ©2016-2020 Gary F. Pollice
 *******************************************************************************/

import escape.EscapeGameBuilder;
import escape.EscapeGameManager;
import escape.EscapeGameManagerImplementation;
import escape.GameObserverImp;
import escape.board.coordinate.Coordinate;
import escape.piece.EscapePiece;
import escape.piece.PieceName;
import org.junit.jupiter.api.Test;

import java.io.File;

import static org.junit.jupiter.api.Assertions.*;

public class GammaRuleTests {
    @Test
    void testMovingNullPieceWithRules() throws Exception
    {
        EscapeGameBuilder egb
                = new EscapeGameBuilder(new File("config/gameWithRules.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        assertFalse(egmi.move(emg.makeCoordinate(1,2),emg.makeCoordinate(2,2)));

    }

    @Test
    void testMovingPlayer2FirstWithRules() throws Exception
    {
        EscapeGameBuilder egb
                = new EscapeGameBuilder(new File("config/gameWithRules.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        assertFalse(egmi.move(emg.makeCoordinate(3,3),emg.makeCoordinate(2,2)));

    }

    @Test
    void testMovingPlayer1FirstWithRules() throws Exception
    {
        EscapeGameBuilder egb
                = new EscapeGameBuilder(new File("config/gameWithRules.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        assertTrue(egmi.move(emg.makeCoordinate(1,3),emg.makeCoordinate(2,2)));

    }

    @Test
    void testMovingPlayer1Then2FirstWithRules() throws Exception
    {
        EscapeGameBuilder egb
                = new EscapeGameBuilder(new File("config/gameWithRules.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        assertTrue(egmi.move(emg.makeCoordinate(1,3),emg.makeCoordinate(2,2)));
        assertTrue(egmi.move(emg.makeCoordinate(3,3),emg.makeCoordinate(4,4)));
    }

    @Test
    void testMovingPlayer1Then1AgainWithRules() throws Exception
    {
        EscapeGameBuilder egb
                = new EscapeGameBuilder(new File("config/gameWithRules.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        assertTrue(egmi.move(emg.makeCoordinate(1,3),emg.makeCoordinate(2,2)));
        assertFalse(egmi.move(emg.makeCoordinate(2,2),emg.makeCoordinate(4,4)));
    }

    @Test
    void testMovingPlayer1ToScore() throws Exception
    {
        EscapeGameBuilder egb
                = new EscapeGameBuilder(new File("config/gameWithRules.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        assertTrue(egmi.move(emg.makeCoordinate(1,3),emg.makeCoordinate(1,2)));
        assertTrue(egmi.move(emg.makeCoordinate(3,3),emg.makeCoordinate(4,4)));
        assertTrue(egmi.move(emg.makeCoordinate(3,1),emg.makeCoordinate(1,2)));
        assertFalse(egmi.move(emg.makeCoordinate(4,4),emg.makeCoordinate(5,5)));
    }

    @Test
    void testMovingUntilTermLimit() throws Exception
    {
        EscapeGameBuilder egb
                = new EscapeGameBuilder(new File("config/gameWithRules.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        assertTrue(egmi.move(emg.makeCoordinate(1,3),emg.makeCoordinate(1,2)));
        assertTrue(egmi.move(emg.makeCoordinate(3,3),emg.makeCoordinate(4,4)));
        assertTrue(egmi.move(emg.makeCoordinate(3,1),emg.makeCoordinate(1,5)));
        assertTrue(egmi.move(emg.makeCoordinate(4,4),emg.makeCoordinate(5,5)));
        assertTrue(egmi.move(emg.makeCoordinate(1,5),emg.makeCoordinate(1,6)));
        assertFalse(egmi.move(emg.makeCoordinate(5,5),emg.makeCoordinate(6,6)));
        assertTrue(egmi.getVictory());
        System.out.println(egmi.getVictoryMessage());
    }

    @Test
    void testMovingUntilTermLimitNoScoreLimit() throws Exception
    {
        EscapeGameBuilder egb
                = new EscapeGameBuilder(new File("config/gameRuleNoScoreLimit.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        assertTrue(egmi.move(emg.makeCoordinate(1,3),emg.makeCoordinate(1,2)));
        assertTrue(egmi.move(emg.makeCoordinate(3,3),emg.makeCoordinate(4,4)));
        assertTrue(egmi.move(emg.makeCoordinate(3,1),emg.makeCoordinate(1,2)));
        assertTrue(egmi.move(emg.makeCoordinate(4,4),emg.makeCoordinate(5,5)));
        assertTrue(egmi.move(emg.makeCoordinate(1,5),emg.makeCoordinate(1,6)));
        assertFalse(egmi.move(emg.makeCoordinate(5,5),emg.makeCoordinate(6,6)));
        assertTrue(egmi.getVictory());
        System.out.println(egmi.getVictoryMessage());
    }


    @Test
    void testMovingPointConflictAttackerWins() throws Exception
    {
        EscapeGameBuilder egb
                = new EscapeGameBuilder(new File("config/gameTestPointConflict.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        assertTrue(egmi.move(emg.makeCoordinate(1,3),emg.makeCoordinate(3,3)));
        EscapePiece afterAttack = emg.getPieceAt(emg.makeCoordinate(3,3));
        assertEquals(5,afterAttack.getValueOfPiece());
        assertEquals(PieceName.FOX,afterAttack.getName());
    }

    @Test
    void testMovingPointConflictAttackerLoses() throws Exception
    {
        EscapeGameBuilder egb
                = new EscapeGameBuilder(new File("config/gameTestPointConflict.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        assertTrue(egmi.move(emg.makeCoordinate(1,3),emg.makeCoordinate(4,4)));
        EscapePiece afterAttack = emg.getPieceAt(emg.makeCoordinate(4,4));
        assertEquals(10,afterAttack.getValueOfPiece());
        assertEquals(PieceName.FROG,afterAttack.getName());
    }

    @Test
    void testMovingPointConflictAttackerTies() throws Exception
    {
        EscapeGameBuilder egb
                = new EscapeGameBuilder(new File("config/gameTestPointConflictTie.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        assertTrue(egmi.move(emg.makeCoordinate(1,3),emg.makeCoordinate(3,3)));
        EscapePiece afterAttacker = emg.getPieceAt(emg.makeCoordinate(1,3));
        EscapePiece afterDefender = emg.getPieceAt(emg.makeCoordinate(3,3));

        assertNull(afterAttacker);
        assertNull(afterDefender);

    }

    @Test
    void testMovingRemoveBattle() throws Exception
    {
        EscapeGameBuilder egb
                = new EscapeGameBuilder(new File("config/gameTestRemoveBattle.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        assertTrue(egmi.move(emg.makeCoordinate(1,3),emg.makeCoordinate(3,3)));
        EscapePiece afterAttacker = emg.getPieceAt(emg.makeCoordinate(1,3));
        EscapePiece afterDefender = emg.getPieceAt(emg.makeCoordinate(3,3));
        assertNull(afterAttacker);
        assertEquals(PieceName.FOX,afterDefender.getName());
        assertEquals(5,afterDefender.getValueOfPiece());

    }

    @Test
    void testMovingNoBattle() throws Exception
    {
        EscapeGameBuilder egb
                = new EscapeGameBuilder(new File("config/testGameNoCombatRules.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        GameObserverImp imp = new GameObserverImp();
        emg.addObserver(imp);
        EscapeGameManagerImplementation egmi = (EscapeGameManagerImplementation) emg;
        assertFalse(egmi.move(emg.makeCoordinate(1,3),emg.makeCoordinate(3,3)));
        EscapePiece afterAttacker = emg.getPieceAt(emg.makeCoordinate(1,3));
        EscapePiece afterDefender = emg.getPieceAt(emg.makeCoordinate(3,3));

        assertEquals(PieceName.FOX, afterAttacker.getName());
        assertEquals(PieceName.HUMMINGBIRD, afterDefender.getName());

    }


}

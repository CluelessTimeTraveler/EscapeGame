/*******************************************************************************
 * This files was developed for CS4233: Object-Oriented Analysis & Design.
 * The course was taken at Worcester Polytechnic Institute.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *
 * Copyright ©2016-2020 Gary F. Pollice
 *******************************************************************************/

import escape.EscapeGameBuilder;
import escape.EscapeGameManager;
import escape.GameObserverImp;
import escape.board.coordinate.Coordinate;
import org.junit.jupiter.api.Test;

import java.io.File;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class GammaObserverTests {


    @Test
    void messageTestMakeMove() throws Exception
    {
        EscapeGameBuilder egb
                = new EscapeGameBuilder(new File("config/messageTest.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        GameObserverImp observer = new GameObserverImp();
        emg.addObserver(observer);
        Coordinate one = emg.makeCoordinate(1,3);
        Coordinate two = emg.makeCoordinate(8,8);
        emg.move(one,two);
        System.out.println(observer.getMessages());
        assertEquals(1,observer.getMessages().size());
    }

    @Test
    void messageTestMakeCoord() throws Exception
    {
        EscapeGameBuilder egb
                = new EscapeGameBuilder(new File("config/messageTest.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        GameObserverImp observer = new GameObserverImp();
        emg.addObserver(observer);
        Coordinate one = emg.makeCoordinate(-1,-2);
        System.out.println(observer.getMessages());
        assertEquals(1,observer.getMessages().size());

    }

    @Test
    void messageTestGetPieceAt() throws Exception
    {
        EscapeGameBuilder egb
                = new EscapeGameBuilder(new File("config/messageTest.xml"));
        EscapeGameManager emg = egb.makeGameManager();
        GameObserverImp observer = new GameObserverImp();
        emg.addObserver(observer);
        Coordinate one = emg.makeCoordinate(3,3);
        emg.getPieceAt(one);
        System.out.println(observer.getMessages());
        emg.removeObserver(observer);
        assertEquals(1,observer.getMessages().size());

    }
}

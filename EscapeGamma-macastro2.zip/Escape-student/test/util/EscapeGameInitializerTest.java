/*******************************************************************************
 * This files was developed for CS4233: Object-Oriented Analysis & Design.
 * The course was taken at Worcester Polytechnic Institute.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Copyright ©2020 Gary F. Pollice
 *******************************************************************************/

package util;

import escape.piece.PieceName;
import escape.piece.Player;
import escape.rule.Rule;
import escape.rule.RuleID;
import escape.util.EscapeGameInitializer;
import escape.util.LocationInitializer;
import escape.util.PieceTypeInitializer;

import javax.xml.bind.*;
import static escape.board.coordinate.CoordinateID.*;
import static escape.piece.MovementPatternID.*;
import static escape.piece.PieceAttributeID.*;
import static escape.piece.PieceAttributeType.BOOLEAN;
import static escape.piece.PieceAttributeType.INTEGER;

import java.io.StringReader;
import static escape.board.LocationType.*;
import static escape.piece.PieceName.*;

/**
 * Test of how to get the EscapeGameInitializer.
 * @version Apr 22, 2020
 */
public class EscapeGameInitializerTest
{
    public static void main(String[] args) throws Exception
    {
        String s = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" + 
        	"<escapeGameInitializer>\n" + 
        	"	<coordinateType>SQUARE</coordinateType>\n" + 
        	"    <!-- Board items -->\n" + 
        	"    <xMax>20</xMax>\n" + 
        	"    <yMax>25</yMax>\n" + 
        	"    <locationInitializers> <!-- An array of these, 0 or more -->\n" + 
        	"        <x>3</x>\n" + 
        	"        <y>4</y>\n" + 
        	"        <locationType>CLEAR</locationType>\n" + 
        	"    </locationInitializers>\n" + 
        	"    <locationInitializers>\n" + 
        	"        <x>5</x>\n" + 
        	"        <y>6</y>\n" + 
        	"        <locationType>BLOCK</locationType>\n" + 
        	"    </locationInitializers>\n" + 
        	"    \n" + 
        	"    <!-- Piece items, an array of pieceTypes, 1 or more -->\n" + 
        	"    <pieceTypes>\n" + 
        	"        <movementPattern>LINEAR</movementPattern>\n" + 
        	"        <pieceName>FROG</pieceName>\n" + 
        	"        <attributes>\n" + 
        	"            <id>DISTANCE</id>\n" + 
        	"            <attrType>INTEGER</attrType>\n" + 
        	"            <intValue>5</intValue>\n" + 
        	"        </attributes>\n" + 
        	"    </pieceTypes>\n" + 
        	"    <pieceTypes>\n" + 
        	"        <attributes>\n" + 
        	"        <movementPattern>LINEAR</movementPattern>\n" + 
        	"        <pieceName>HORSE</pieceName>\n" + 
        	"            <id>UNBLOCK</id>\n" + 
        	"            <attrType>BOOLEAN</attrType>\n" + 
        	"            <booleanValue>false</booleanValue>\n" + 
        	"        </attributes>\n" + 
        	"    </pieceTypes>\n" + 
        	"</escapeGameInitializer>";
        JAXBContext contextObj 
            = JAXBContext.newInstance(EscapeGameInitializer.class);  
        Marshaller mob = contextObj.createMarshaller();  
        mob.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        
        EscapeGameInitializer egi = new EscapeGameInitializer();
        egi.setRules();
        egi.setxMax(8);
        egi.setyMax(8);
        egi.setCoordinateType(SQUARE);
        egi.setLocationInitializers(
        		new LocationInitializer(3,1,CLEAR,Player.PLAYER1,FOX),
				new LocationInitializer(1,3,CLEAR,Player.PLAYER1,FOX),
				new LocationInitializer(1,5,CLEAR,Player.PLAYER2,FOX),
				new LocationInitializer(3,3,CLEAR,Player.PLAYER2,HUMMINGBIRD),
				new LocationInitializer(4,4,CLEAR,Player.PLAYER2,FROG),
				new LocationInitializer(1,2,EXIT,null,null),
        	new LocationInitializer(1,1,BLOCK, null, null));

        PieceTypeInitializer.PieceAttribute frogAttr = new PieceTypeInitializer.PieceAttribute();
		frogAttr.setAttrType(INTEGER);
		frogAttr.setId(DISTANCE);
		frogAttr.setIntValue(5);
		PieceTypeInitializer.PieceAttribute jumpFrog = new PieceTypeInitializer.PieceAttribute();
		jumpFrog.setAttrType(INTEGER);
		jumpFrog.setId(VALUE);
		jumpFrog.setIntValue(20);
        PieceTypeInitializer pi = new PieceTypeInitializer();
        pi.setPieceName(FROG);
        pi.setMovementPattern(LINEAR);
        pi.setAttributes(frogAttr,jumpFrog);

		PieceTypeInitializer.PieceAttribute attrHum = new PieceTypeInitializer.PieceAttribute();
		attrHum.setAttrType(INTEGER);
		attrHum.setId(FLY);
		PieceTypeInitializer.PieceAttribute attrHum2 = new PieceTypeInitializer.PieceAttribute();
		attrHum2.setId(VALUE);
		attrHum2.setAttrType(INTEGER);
		attrHum2.setIntValue(5);
		PieceTypeInitializer humBirdFly = new PieceTypeInitializer();
		humBirdFly.setPieceName(HUMMINGBIRD);
		humBirdFly.setMovementPattern(OMNI);
		humBirdFly.setAttributes(attrHum,attrHum2);


		PieceTypeInitializer.PieceAttribute FoxAttr = new PieceTypeInitializer.PieceAttribute();
		FoxAttr.setAttrType(INTEGER);
		FoxAttr.setId(VALUE);
		//FoxAttr.setIntValue(10);
		FoxAttr.setIntValue(5);
		PieceTypeInitializer.PieceAttribute attr2 = new PieceTypeInitializer.PieceAttribute();
		attr2.setAttrType(BOOLEAN);
		attr2.setId(UNBLOCK);
		attr2.setBooleanValue(true);
		PieceTypeInitializer.PieceAttribute attr3 = new PieceTypeInitializer.PieceAttribute();
		attr3.setAttrType(INTEGER);
		attr3.setId(DISTANCE);
		attr3.setIntValue(4);
		PieceTypeInitializer fox = new PieceTypeInitializer();
		fox.setPieceName(FOX);
		fox.setMovementPattern(OMNI);
		fox.setAttributes(FoxAttr,attr2,attr3);



		egi.setPieceTypes(pi, humBirdFly, fox);


		Rule score = new Rule();
		score.setId(RuleID.SCORE);
//		score.setIntValue(20);
		Rule turnLim = new Rule();
//		turnLim.setId(RuleID.TURN_LIMIT);
//		turnLim.setIntValue(5);

		Rule pointConflict = new Rule();
		pointConflict.setId(RuleID.REMOVE);

		egi.setRules(score);


        mob.marshal(egi, System.out);
        
        EscapeGameInitializer egi1;
        Unmarshaller mub = contextObj.createUnmarshaller();
        egi1 = (EscapeGameInitializer)mub.unmarshal(new StringReader(s));
        System.out.println(egi1.toString());
    }
}

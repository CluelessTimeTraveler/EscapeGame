package escape.rule;

public enum RuleID {
    TURN_LIMIT, POINT_CONFLICT, REMOVE, SCORE;

}

/*******************************************************************************
 * This files was developed for CS4233: Object-Oriented Analysis & Design.
 * The course was taken at Worcester Polytechnic Institute.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *
 * Copyright ©2016-2020 Gary F. Pollice
 *******************************************************************************/

package escape;

import escape.board.Board;
import escape.board.LocationType;
import escape.board.coordinate.Coordinate;
import escape.exception.EscapeException;
import escape.piece.EscapePiece;
import escape.piece.Player;
import escape.validators.MovementValidator;
import escape.validators.RuleValidator;

import java.util.ArrayList;

/**
 * An implementation of the game manager interface
 * @param <C> Coordinate system
 */
public class EscapeGameManagerImplementation<C extends Coordinate> implements EscapeGameManager<C>{

    private Board<C> board;
    private ArrayList<GameObserver> observers;
    private MovementValidator moveValidator;
    private RuleValidator ruleValidator;

    boolean victory = false;
    String victoryMessage = "";

    public EscapeGameManagerImplementation(Board<C> board, MovementValidator moveValidator, RuleValidator ruleValidator) {
        this.board = board;
        this.moveValidator = moveValidator;
        this.ruleValidator = ruleValidator;
        this.observers = new ArrayList<>();
    }


    /**
     * Make the move in the current game.
     * @param from starting location
     * @param to ending location
     * @return true if the move was legal, false otherwise
     */
    @Override
    public boolean move(Coordinate from, Coordinate to) {
        if(victory){
            notifyObservers(victoryMessage,null);
            return false;
        }

        moveValidator.setValidator(getPieceAt(from),board,to,from);

        if(moveValidator.validate()){
            EscapePiece movingPiece = getPieceAt(from);

            if(ruleValidator.isSetupFromFile() && !ruleValidator.canPlayerMakeMove(movingPiece)){
                notifyObservers("It is not that player's move",null);
                return false;
            }
            ruleValidator.isMoving(movingPiece);

            EscapePiece pieceAtTo = board.getPieceAt((C) to);
            EscapePiece combatWinner = getPieceAt(from);
            if(pieceAtTo != null){
                try{
                    combatWinner = ruleValidator.handleCombat(movingPiece,pieceAtTo);
                } catch (EscapeException e) {
                    notifyObservers("No combat rules specified, invalid move",e);
                    return false;
                }
            }
            if(combatWinner!=null){
                board.putPieceAt(combatWinner, (C) to);
            }else{
                board.removePiece(to);
            }

            board.removePiece(from);


            if(board.getLocation((C) to) == LocationType.EXIT){

                ruleValidator.addScore(movingPiece);
                board.removePiece(to);

            }
            checkVictory();
            return true;

        }else{
            notifyObservers("Invalid move attempted",null);
            return false;
        }
    }

    /**
     * Checks if victory has been achieved by a player at the end of a move
     */
    private void checkVictory() {
        switch(ruleValidator.hasPlayerWon()){
            case 1:
                declareVictory(Player.PLAYER1);
                break;
            case 2:
                declareVictory(Player.PLAYER2);
                break;
            case 0:
                declareVictory(null);
                break;
            case -1:

        }
    }


    /**
     * Declares victory for the specified player
     * @param player
     */
    private void declareVictory(Player player){
        if(player!=null){
            notifyObservers(player + "wins",null);
            victory = true;
            victoryMessage = "Game is over and " + player + " has won";
        }else{
            notifyObservers("Game was tied",null);
            victory = true;
            victoryMessage = "Game was tied";
        }

    }


    /**
     * Return the piece located at the specified coordinate. If executing
     * this method in the game instance causes an exception, then this method
     * returns null and sets the status message appropriately.
     * @param coordinate the location to probe
     * @return the piece at the specified location or null if there is none
     */
    @Override
    public EscapePiece getPieceAt(Coordinate coordinate) {
        EscapePiece ep = board.getPieceAt((C) coordinate);
        if(ep == null){
            String message = "Unable to find piece at coordinate(X=" + coordinate.getX() + " Y=" + coordinate.getY() + ")";
            notifyObservers(message,null);
            return null;
        }
        return ep;
    }

    /**
     * Returns a coordinate of the appropriate type. If the coordinate cannot be
     * created, then null is returned and the status message is set appropriately.
     * @param x the x component
     * @param y the y component
     * @return the coordinate or null if the coordinate cannot be
     */
    @Override
    public C makeCoordinate(int x, int y) {
        Coordinate c = board.createCoord(x,y);
        if(c==null){
            notifyObservers("Failed to create coordinate at X=" + x + " Y=" + y, null);
            return null;
        }
        return (C) c;

    }

    /**
     * Adds the observer to the list of observers to notify
     * @param observer
     * @return
     */
    @Override
    public GameObserver addObserver(GameObserver observer) {
        observers.add(observer);
        return observer;
    }
    /**
     * Removes the observer from the list of observers to notify
     * @param observer
     * @return
     */
    @Override
    public GameObserver removeObserver(GameObserver observer) {
        observers.add(observer);
        return observer;
    }

    /**
     * Notifies the list of observers
     * @param message
     * @param cause
     */
    public void notifyObservers(String message, Throwable cause){
        if(cause == null){
            for(GameObserver go : observers){
                go.notify(message);
            }
        }else{
            for(GameObserver go : observers){
                go.notify(message, cause);
            }
        }
    }

    /**
     * Returns wether the board is in a victory state or not
     * @return
     */
    public boolean getVictory(){
        return victory;
    }
    /**
     * Returns the victory message
     * @return
     */
    public String getVictoryMessage(){
        return victoryMessage;
    }
}

/*******************************************************************************
 * This files was developed for CS4233: Object-Oriented Analysis & Design.
 * The course was taken at Worcester Polytechnic Institute.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *
 * Copyright ©2016-2020 Gary F. Pollice
 *******************************************************************************/

package escape;

import java.util.ArrayList;
import java.util.List;


/**
 * An implementation of the gameobserver interface
 */
public class GameObserverImp implements GameObserver{


    private ArrayList<String> messages = new ArrayList<>();

    /**
     * Adds the message to the observer message list
     * @param message
     */
    @Override
    public void notify(String message) {
        messages.add(message);
    }
    /**
     * Adds the message to the observer message list
     * @param message
     */
    @Override
    public void notify(String message, Throwable cause) {
        messages.add(message + " : " + cause.getMessage());
    }

    /**
     * Returns the messages for testing purposes
     * @return
     */
    public List<String> getMessages(){
        return messages;
    }
}

/*******************************************************************************
 * This files was developed for CS4233: Object-Oriented Analysis & Design.
 * The course was taken at Worcester Polytechnic Institute.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *
 * Copyright ©2016-2020 Gary F. Pollice
 *******************************************************************************/

package escape.validators;

import escape.board.Board;
import escape.exception.EscapeException;
import escape.piece.EscapePiece;
import escape.piece.Player;
import escape.rule.Rule;

import java.util.ArrayList;
import java.util.HashMap;

public class EscapeRuleValidator implements RuleValidator{


    int winningScore = -1; //-1 signifies not set
    HashMap<Player,Integer> playerScores;


    int limitTurns = -1;
    int currentTurn = 0;

    boolean battleRemove = false;
    boolean battleConflict = false;

    boolean setupFromFile = false;

    Player beforeLastPlayerToMove = Player.PLAYER1;
    Player lastPlayerToMove = Player.PLAYER2;

    public boolean canPlayerMakeMove(EscapePiece ep){
        return (ep.getPlayer() != lastPlayerToMove);
    }


    public void isMoving(EscapePiece ep){
        if(ep.getPlayer()==beforeLastPlayerToMove){
            currentTurn++;
        }
        beforeLastPlayerToMove = lastPlayerToMove;
        lastPlayerToMove = ep.getPlayer();
    }


    public int addScore(EscapePiece ep){
        int currentScore = playerScores.get(ep.getPlayer());
        currentScore+=ep.getValueOfPiece();
        playerScores.put(ep.getPlayer(),currentScore);
        return currentScore;
    }

    /**
     * Compares a score to the winningScore
     * @param score
     * @return true if score is greater than or equal to winningScore
     */
    public boolean checkScore(int score){
        if(winningScore == -1){
            return false;
        }
        return(score >= winningScore);
    }


    /**
     * Static factory method for create the escapeRuleValidator
     * @param rules a set of rules
     * @return a new RuleValidator
     */
    public static RuleValidator makeRuleValidator(Rule[] rules){
        EscapeRuleValidator erv = new EscapeRuleValidator();
        if(rules == null){
            erv.playerScores = new HashMap<>();
            erv.playerScores.put(Player.PLAYER1,0);
            erv.playerScores.put(Player.PLAYER2,0);
            return erv;
        }
        for(Rule r : rules){
            switch(r.getId()){
                case TURN_LIMIT:
                    erv.setLimitTurns(r.getIntValue());
                    break;
                case SCORE:
                    erv.setWinningScore(r.getIntValue());
                    break;
                case REMOVE:
                    erv.setBattleRemove(true);
                    break;
                case POINT_CONFLICT:
                    erv.setBattleConflict(true);
                    break;
            }
        }
        erv.playerScores = new HashMap<>();
        erv.playerScores.put(Player.PLAYER1,0);
        erv.playerScores.put(Player.PLAYER2,0);
        erv.setupFromFile = true;
        return erv;
    }


    public EscapePiece handleCombat(EscapePiece attacker, EscapePiece defender) throws EscapeException{
        int attackerValue = attacker.getValueOfPiece();
        int defenderValue = defender.getValueOfPiece();
        if(battleConflict){
                if(attackerValue > defenderValue){
                    attacker.setValueOfPiece(attackerValue-defenderValue);
                    return attacker;
                }
                if(attackerValue < defenderValue){
                    defender.setValueOfPiece(defenderValue-attackerValue);
                    return defender;
                }
                if(attackerValue==defenderValue){
                    return null;
                }
        }
        if(!battleConflict && !battleRemove && setupFromFile){
            throw new EscapeException("No engagement rule, move invalid");
        }
        return attacker;
    }


    public void setWinningScore(int winningScore) {
        this.winningScore = winningScore;
    }

    public int hasPlayerWon(){
        if(winningScore != -1){

            if(checkScore(playerScores.get(Player.PLAYER1))){
                return 1;
            }

            if(checkScore(playerScores.get(Player.PLAYER1))){
                return 2;
            }
        }

        if(limitTurns != -1 && currentTurn >= limitTurns){
            int winner = withHighestScore();
            return winner;
        }

        return -1;
    }

    int withHighestScore(){
        if(playerScores.get(Player.PLAYER1) > playerScores.get(Player.PLAYER2)){
            return 1;
        }
        if(playerScores.get(Player.PLAYER2) > playerScores.get(Player.PLAYER1)){
            return 2;
        }else{
            return 0;
        }

    }

    public int getLimitTurns() {
        return limitTurns;
    }

    public void setLimitTurns(int limitTurns) {
        this.limitTurns = limitTurns;
    }


    public void setBattleRemove(boolean battleRemove) {
        this.battleRemove = battleRemove;
    }

    public void setBattleConflict(boolean battleConflict) {
        this.battleConflict = battleConflict;
    }

    public boolean isSetupFromFile(){
        return setupFromFile;
    }
}

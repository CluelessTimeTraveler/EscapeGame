
package escape.validators;

import escape.exception.EscapeException;
import escape.piece.EscapePiece;

/**
 * An interface for the checking of rules so that it can be changed if needed at a later date
 */
public interface RuleValidator {
    /**
     * Adds score to a given game piece's player based on its value
     * @param ep
     * @return the new score
     */
    int addScore(EscapePiece ep);

    /**
     * Checks if a given score means victory
     * @param score
     * @return
     */
    boolean checkScore(int score);

    /**
     * Checks if a piece's player is able to make a move at the current moment
     * @param ep
     * @return
     */
    boolean canPlayerMakeMove(EscapePiece ep);

    /**
     * Checks if the RuleValidator was setup from a file or the default values were used
     * @return
     */
    boolean isSetupFromFile();

    /**
     * Tells the validator that a move that is already valid will be made
     * Update the needed fields inside of the validator
     * @param ep
     */
    void isMoving(EscapePiece ep);

    /**
     * Checks if a player has won
     * @return 1 for player 1 has one, 2 for player 2, 0 for tie, -1 for no victory
     */
    int hasPlayerWon();

    /**
     * Handles combat between an attacker piece and defender piece
     * @param attacker
     * @param defender
     * @return the updated victor
     * @throws EscapeException
     */
    EscapePiece handleCombat(EscapePiece attacker, EscapePiece defender) throws EscapeException;
}
